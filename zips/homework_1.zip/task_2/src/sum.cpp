// @file      sum.cpp
// @author    Ignacio Vizzo     [ivizzo@uni-bonn.de]
//
// Copyright (c) 2019 Ignacio Vizzo, all rights reserved
#include "ipb_arithmetic/sum.hpp"

float MySum(float x, float y) { return x + y; }
